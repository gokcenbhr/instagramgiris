package com.example.myapplicationinstagram;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;

import android.view.MenuItem;
import android.widget.AdapterView.OnItemSelectedListener;

import Cerceve.AramaFragment;
import Cerceve.BildirimFragment;
import Cerceve.HomeFragment;
import Cerceve.ProfilFragment;

public class AnaSayfaActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    Fragment seciliCerceve=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ana_sayfa);

        bottomNavigationView= findViewById(R.id.bottom_navigation);

        bottomNavigationView.setOnItemSelectedListener(OnItemSelectedListener);

        getSupportFragmentManager().beginTransaction().replace(R.id.cerceve_kapsayici,new HomeFragment()).commit();


    }

    private NavigationBarView.OnItemSelectedListener OnItemSelectedListener=new NavigationBarView.OnItemSelectedListener(){
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem){

            switch (menuItem.getItemId())
            {
                case R.id.nav_home:

                //Ana çerçeve çağır

                    seciliCerceve= new HomeFragment();

                    break;
                case R.id.nav_arama:

                    //Arama çerçevesini çağır

                    seciliCerceve=new AramaFragment();
                    break;
                case R.id.nav_ekle:
                    //çerçeve boş olsun. gönderi aktiviteye git

                    seciliCerceve=null;
                    startActivity(new Intent(AnaSayfaActivity.this,GonderiActivity.class));


                    break;
                case R.id.nav_kalp:

                 //bildirim çerçevesini çağır

                    seciliCerceve=new BildirimFragment();
                    break;
                case R.id.nav_profil:

                    SharedPreferences.Editor editor=getSharedPreferences("PREFS",MODE_PRIVATE).edit();
                    editor.putString("profileid", FirebaseAuth.getInstance().getCurrentUser().getUid());
                    //profil çerçeve çağır

                    seciliCerceve=new ProfilFragment();
                    break;
            }

            if(seciliCerceve != null)
            {
                getSupportFragmentManager().beginTransaction().replace(R.id.cerceve_kapsayici,seciliCerceve).commit();
            }



            return true;
        }
    };





}